
package queue;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class QueueSystem extends javax.swing.JFrame {
    
    //Store mouse position for window dragging
    int xMouse;
    int yMouse;
    int timeRun = 0;

    // Constructor for the QueueSystem class
    public QueueSystem() {
        initComponents();
        inputX.setText("");
        varx.setText(""); 
        vary.setText(""); 
        var1.setText(""); 
        var2.setText(""); 
        var3.setText(""); 
        var3.setText(""); 
        var4.setText(""); 
        var5.setText(""); 
        var6.setText(""); 
        var7.setText(""); 
        var8.setText(""); 
        notes.setVisible(false);
        
        
        
        
        
        
        
        setLocationRelativeTo(this);
        
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        page = new javax.swing.JPanel();
        enqueue = new javax.swing.JPanel();
        TF1 = new javax.swing.JLabel();
        dequeue = new javax.swing.JPanel();
        TF2 = new javax.swing.JLabel();
        check = new javax.swing.JPanel();
        TF3 = new javax.swing.JLabel();
        notes = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        varx = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        var1 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        vary = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        var2 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        var3 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        var4 = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        var5 = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        var6 = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        var7 = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        var8 = new javax.swing.JTextField();
        inputX = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        title = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        page.setBackground(new java.awt.Color(204, 204, 204));
        page.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        enqueue.setBackground(new java.awt.Color(255, 255, 255));
        enqueue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        enqueue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                enqueueMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                enqueueMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                enqueueMouseExited(evt);
            }
        });
        enqueue.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TF1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        TF1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TF1.setText("Enqueue");
        enqueue.add(TF1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 130, 40));

        page.add(enqueue, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 170, 40));

        dequeue.setBackground(new java.awt.Color(255, 255, 255));
        dequeue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dequeue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dequeueMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dequeueMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dequeueMouseExited(evt);
            }
        });
        dequeue.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TF2.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        TF2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TF2.setText("Dequeue");
        dequeue.add(TF2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 130, 40));

        page.add(dequeue, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 170, 40));

        check.setBackground(new java.awt.Color(255, 255, 255));
        check.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        check.setPreferredSize(new java.awt.Dimension(200, 175));
        check.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                checkMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                checkMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                checkMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                checkMousePressed(evt);
            }
        });
        check.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TF3.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        TF3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TF3.setText("Clear");
        check.add(TF3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 130, 40));

        page.add(check, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 170, 60));

        notes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        notes.setText("*The seat is full");
        page.add(notes, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 400, 130, 40));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        varx.setEditable(false);
        varx.setBackground(new java.awt.Color(255, 255, 255));
        varx.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        varx.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        varx.setBorder(null);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(varx, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(varx, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        page.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, 90, 80));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var1.setEditable(false);
        var1.setBackground(new java.awt.Color(255, 255, 255));
        var1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var1.setBorder(null);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var1, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(var1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        page.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, 90, 80));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        vary.setEditable(false);
        vary.setBackground(new java.awt.Color(255, 255, 255));
        vary.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        vary.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        vary.setBorder(null);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(vary, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(vary, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        page.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 380, 90, 80));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var2.setEditable(false);
        var2.setBackground(new java.awt.Color(255, 255, 255));
        var2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var2.setBorder(null);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var2, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var2, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 380, 90, 80));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var3.setEditable(false);
        var3.setBackground(new java.awt.Color(255, 255, 255));
        var3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var3.setBorder(null);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var3, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var3, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 260, 90, 80));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var4.setEditable(false);
        var4.setBackground(new java.awt.Color(255, 255, 255));
        var4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var4.setBorder(null);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var4, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var4, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, 90, 80));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var5.setEditable(false);
        var5.setBackground(new java.awt.Color(255, 255, 255));
        var5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var5.setBorder(null);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var5, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var5, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 20, 90, 80));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var6.setEditable(false);
        var6.setBackground(new java.awt.Color(255, 255, 255));
        var6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var6.setBorder(null);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var6, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var6, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 20, 90, 80));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var7.setEditable(false);
        var7.setBackground(new java.awt.Color(255, 255, 255));
        var7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var7.setBorder(null);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var7, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var7, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 20, 90, 80));

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        var8.setEditable(false);
        var8.setBackground(new java.awt.Color(255, 255, 255));
        var8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        var8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        var8.setBorder(null);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var8, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(var8, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );

        page.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 20, 90, 80));

        inputX.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        inputX.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        page.add(inputX, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 170, 40));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Enter the passenger name");
        page.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Exit");
        page.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 45, 40, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("4");
        page.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 460, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("3");
        page.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("2");
        page.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("1");
        page.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Entrance");
        page.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 220, -1, -1));

        jPanel2.add(page, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1050, 550));

        title.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                titleMouseDragged(evt);
            }
        });
        title.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                titleMousePressed(evt);
            }
        });
        title.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jLabel2.setText("Airline Reservation System");
        title.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Back");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        title.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, -1, -1));

        jPanel2.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 60));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    // Method to handle window drag when the title bar is dragged
    private void titleMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_titleMouseDragged
        
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();

         // Set the new location of the window 
        this.setLocation(x - xMouse,y - yMouse);
    }//GEN-LAST:event_titleMouseDragged

     // Method to store initial mouse position
    private void titleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_titleMousePressed
       
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_titleMousePressed

    // Method triggered when the window is activated
    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
     
    }//GEN-LAST:event_formWindowActivated

    // Method triggered when the button is clicked
    private void enqueueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enqueueMouseClicked
       
      String data = inputX.getText();
        
      // Check if data is empty
         if (data.equals("")){
       JOptionPane.showMessageDialog(null,"Enter data");    
       
        }else {
        Thread th=new Thread(){
            @Override
            public void run (){
                try{
                    for(int a=0;a<=10;a++){
                        Thread.sleep(500);
                        if (a==1){run1();}
                        if (a==2){run2();}
                        if (a==3){run3();}
                        if (a==4){run4();}
                        if (a==5){run5();}
                        if (a==6){run6();}
                        if (a==7){checkHead();checkTail();}
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
        };th.start();
        
        
        
        
         }
        
    }//GEN-LAST:event_enqueueMouseClicked

    
    private void run1(){
        String data = varx.getText();
        String input = inputX.getText();

        
       if (data.equals("")){
           
       varx.setText(input);
        }
    
    }
    
    private void run2(){
        String data = var1.getText();
        String input = varx.getText();

        
       if (data.equals("")){
           
       var1.setText(input);
       varx.setText("");
        }
    
    }
    
    private void run3(){
        String data = var2.getText();
        String a1 = var1.getText(); 
        
        
       if (data.equals("")){
       var2.setText(a1);
       var1.setText("");
       notes.setVisible(false);
      
       vary.setText("");
        } else {
           vary.setText(a1);
           var1.setText("");
           notes.setVisible(true);
          
       }
    }
    
    private void run4(){
        String data = var3.getText();
        String a12 = var2.getText(); 
        
        
       if (data.equals("")){
       var3.setText(a12);
       var2.setText("");
       }   
    }
    
    private void run5(){
        String data = var4.getText();
        String a13 = var3.getText(); 
        
        
       if (data.equals("")){
       var4.setText(a13);
       var3.setText("");
        } 
    }
    
    private void run6(){
        String data = var5.getText();
        String a14 = var4.getText(); 
        
        
       if (data.equals("")){
       var5.setText(a14);
       var4.setText("");
        }
    }
    
    public void checkHead(){
        
        String d = var2.getText(); 
        String e = var3.getText(); 
        String f = var4.getText(); 
        String g = var5.getText(); 
        String h = var6.getText(); 
        
       
        if(f.equals("") && !(e.equals("")) ){
            
           
            
            
            
            
        } else if(g.equals("") && !(f.equals("")) ){
           
            
            
    } else if(h.equals("") && !(g.equals("")) ){
            
            
    }
        
    }

    
   public void checkMD1(){
       Thread th=new Thread(){
            @Override
            public void run (){
                try{
                    for(int a=0;a<=10;a++){
                        Thread.sleep(500);
                        if (a==1){runMD1();}
                        if (a==2){runMD2();}
                        if (a==3){runMD3();}
                        if (a==4){runMD4();}
                        if (a==5){checkHead();checkTail();}
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
        };th.start();
        
   }
   
   private void runMD1(){
       String v4 = var4.getText();
       String v5 = var5.getText();
       if (v5.equals("") && !(v4.equals(""))){
       var5.setText(v4);
       var4.setText("");
        }
   }
   
   private void runMD2(){
       String v3 = var3.getText();
       String v4 = var4.getText();
       if (v4.equals("") && !(v3.equals(""))){
       var4.setText(v3);
       var3.setText("");
        }
   }
    
   private void runMD3(){
       String v2 = var2.getText();
       String v3 = var3.getText();
       if (v3.equals("") && !(v2.equals(""))){
       var3.setText(v2);
       var2.setText("");
        }
   }
   
   private void runMD4(){
       String v1 = var1.getText();
       String v2 = var2.getText();
       if (v2.equals("") && !(v1.equals(""))){
       var2.setText(v1);
       var1.setText("");
        }
   }
   
   
    
    public void checkTail(){
        //Extract text from GUI components
        String c = var1.getText(); 
        String d = var2.getText(); 
        String e = var3.getText(); 
        String f = var4.getText(); 
        String g = var5.getText(); 
        String h = var6.getText(); 
        
         // Check conditions to update the tail of the queue
        if(f.equals("") && !(g.equals(""))){
            
            
            
            
            
        } else if(e.equals("") && !(f.equals("")) ){
            
            
            
    } else if(d.equals("") && !(e.equals("")) ){
            
            
           
            
    } else if(c.equals("") && !(d.equals("")) ){
            
            
            
    }
        
    }
    
    // Method to run a sequence of tasks on a separate thread
    private void run7(){
        Thread th=new Thread(){
            @Override
            public void run (){
                try{
                    for(int a=0;a<=7;a++){
                        Thread.sleep(800);
                        // Execute different tasks based on the value of 'a'
                        if (a==1){run7a();}
                        if (a==2){run7b();checkHead();}
                        if (a==3){run7c();}
                        if (a==4){run7d();}
                        if (a==5){checkMD1();}
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
        };th.start();
        
         
    }
    
    private void run7a(){
        String data = var5.getText();
        var6.setText(data);
        var5.setText("");
    }
    
     private void run7b(){
        String data = var6.getText();
        var7.setText(data);
        var6.setText("");
    }
    
     private void run7c(){
        String data = var7.getText();
        var7.setText("");
        var8.setText(data);
        
    }
    
     private void run7d(){
         String data = var7.getText();
         var7.setText(data);
         var8.setText(data);
    }
    
     // Method to handle mouse events for enqueue operation
    private void enqueueMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enqueueMouseEntered
        
        x1();
    }//GEN-LAST:event_enqueueMouseEntered

     public void x1() {
        
        
    }
     
    private void enqueueMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enqueueMouseExited
        
        y1();
    }//GEN-LAST:event_enqueueMouseExited

    public void y1() {
        
    }
    
    private void dequeueMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dequeueMouseEntered
        
        x2();
    }//GEN-LAST:event_dequeueMouseEntered

    public void x2() {
        
    }
    
    private void dequeueMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dequeueMouseExited
       
        y2();
    }//GEN-LAST:event_dequeueMouseExited

    public void y2() {
        
    }
    
    private void checkMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkMouseClicked
        
        run7x();
    }//GEN-LAST:event_checkMouseClicked

    private void run7x(){
        String d = var2.getText(); 
        String e = var3.getText(); 
        String f = var4.getText(); 
        String g = var5.getText(); 
        
        if(d.equals("") && e.equals("") && f.equals("") && g.equals("")){
            
           
            
            
           
            
         JOptionPane.showMessageDialog(null,"The data has been cleared");  
         
        }else{
        Thread th=new Thread(){
            @Override
            public void run (){
                try{
                    for(int a=0;a<=7;a++){
                        Thread.sleep(800);
                        if (a==1){run7a();}
                        if (a==2){run7b();checkHead();}
                        if (a==3){run7c();}
                        if (a==4){run7d();}
                        if (a==5){checkMD2();}
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
        };th.start();
        }
    }
    
    public void checkMD2(){
       Thread th=new Thread(){
            @Override
            public void run (){
                try{
                    for(int a=0;a<=10;a++){
                        Thread.sleep(500);
                        if (a==1){runMD1();}
                        if (a==2){runMD2();}
                        if (a==3){runMD3();}
                        if (a==4){runMD4();}
                        if (a==5){checkHead();checkTail();}
                        if (a==6){run7x();}
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
        };th.start();
        
   }
    
    
    private void checkMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkMouseEntered
       
        x3();
    }//GEN-LAST:event_checkMouseEntered

    public void x3() {
        
    }
    
    private void checkMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkMouseExited
        
        y3();
    }//GEN-LAST:event_checkMouseExited

    public void y3() {
        
    }
    
    private void checkMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkMousePressed
       
    }//GEN-LAST:event_checkMousePressed

    private void dequeueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dequeueMouseClicked
        
       run7();
        
        
    }//GEN-LAST:event_dequeueMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        
        Loginform obj =new Loginform(); 
        obj.setVisible(true);
        dispose();
        
        
    }//GEN-LAST:event_jLabel3MouseClicked
// Main method to execute the program
    public static void main(String args[]) {
        

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QueueSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TF1;
    private javax.swing.JLabel TF2;
    private javax.swing.JLabel TF3;
    private javax.swing.JPanel check;
    private javax.swing.JPanel dequeue;
    private javax.swing.JPanel enqueue;
    private javax.swing.JTextField inputX;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel notes;
    private javax.swing.JPanel page;
    private javax.swing.JPanel title;
    private javax.swing.JTextField var1;
    private javax.swing.JTextField var2;
    private javax.swing.JTextField var3;
    private javax.swing.JTextField var4;
    private javax.swing.JTextField var5;
    private javax.swing.JTextField var6;
    private javax.swing.JTextField var7;
    private javax.swing.JTextField var8;
    private javax.swing.JTextField varx;
    private javax.swing.JTextField vary;
    // End of variables declaration//GEN-END:variables
}